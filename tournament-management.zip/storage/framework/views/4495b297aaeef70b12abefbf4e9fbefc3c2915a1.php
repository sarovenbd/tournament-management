

<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <!-- Hero Section Begin -->
    <section class="hero-section set-bg" data-setbg="<?php echo e(is_null(setting('hero.image'))?asset('frontend/assets/img/header-bg.jpg'):Voyager::image(setting('hero.image'))); ?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hs-item">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="hs-text">
                                        <h4><?php echo e(is_null(setting('hero.small_title'))?"eSports Gaming":setting('hero.small_title')); ?></h4>
                                        <h2><?php echo e(is_null(setting('hero.large_title'))?"We organize esports tournament":setting('hero.large_title')); ?></h2>
                                        <a href="/tournaments" class="btn btn-lg btn-info">See Tournaments</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Match Section Begin -->
    <?php echo $__env->make('sections.matches', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Match Section End -->

    <!-- latest-news Section Begin -->
    <?php if(count($latest_posts)>0): ?>
        <section class="latest-news-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 p-0">
                        <h3 class="title">News Feed</h3>
                        <hr class="line-info">
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $latest_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-sm-6 p-0">
                            <div class="latest-news-item set-bg" data-setbg="<?php echo e(is_null($post->image)? asset('frontend/assets/img/default.png') :Voyager::image($post->image)); ?>">
                                <div class="si-tag"><?php echo e(!is_null($post->category_id)?$post->category->getTranslatedAttribute('name'):'Uncategorized'); ?></div>
                                <div class="si-text">
                                    <h5><a href="/post/<?php echo e($post->slug); ?>"><?php echo e($post->getTranslatedAttribute('title')); ?></a></h5>
                                    <ul class="m-0 p-0">
                                        <li><i class="fa fa-calendar"></i> <?php echo e($post->created_at->diffForHumans()); ?></li>
                                        <li><i class="fa fa-user"></i> <?php echo e(is_null($post->authorId)?"Admin":$post->authorId->name); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
            </div>
        </section> 
    <?php endif; ?>
    <!-- latest-news Section End -->

    <!-- Team section Begin-->
    <?php echo $__env->make('sections.players', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Team Section End-->

    <!-- Video Section Begin -->
    <?php echo $__env->make('sections.live-streams', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Video Section End -->

    <!-- Testimony Section Begin -->
    <?php echo $__env->make('sections.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Testimony Section End -->

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
  <script src="<?php echo e(asset('frontend/assets/custom-js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ashah\Desktop\New folder (2)\tournament-management\resources\views/landing-page.blade.php ENDPATH**/ ?>