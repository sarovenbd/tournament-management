<?php if(count($upcoming_results)>0 || count($finished_results)>0): ?>
<section class="match-section set-bg" data-setbg="<?php echo e(asset('frontend/assets/img/match/match-bg.jpg')); ?>">
    <div class="container">
        <div class="row">
            <?php if(count($upcoming_results)>0): ?>
                <div class="col-lg-6">
                    <div class="ms-content">
                        <h4>Next Match</h4>

                        <?php $__currentLoopData = $upcoming_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mc-table">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td class="left-team">
                                                <img src="<?php echo e(is_null($result->teamA->logo)?asset('frontend/assets/img/default.png'):Voyager::image($result->teamA->logo)); ?>" alt="team a">
                                                <h6><?php echo e($result->teamA->title); ?></h6>
                                            </td>
                                            <td class="mt-content">
                                                <div class="mc-op"><?php echo e($result->tournament->getTranslatedAttribute('title')); ?></div>
                                                <h4>VS</h4>
                                                <div class="mc-op"><?php echo e($result->tournament->date); ?></div>
                                            </td>
                                            <td class="right-team">
                                                <img src="<?php echo e(is_null($result->teamB->logo)?asset('frontend/assets/img/default.png'):Voyager::image($result->teamB->logo)); ?>" alt="team b">
                                                <h6><?php echo e($result->teamB->title); ?></h6>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>  
            <?php endif; ?>
            
            <?php if(count($finished_results)>0): ?>
                <div class="col-lg-6">
                    <div class="ms-content">
                        <h4>Recent Results</h4>

                        <?php $__currentLoopData = $finished_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mc-table">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td class="left-team">
                                                <img src="<?php echo e(is_null($result->teamA->logo)?asset('frontend/assets/img/default.png'):Voyager::image($result->teamA->logo)); ?>" alt="team a">
                                                <h6><?php echo e($result->teamA->getTranslatedAttribute('title')); ?></h6>
                                            </td>
                                            <td class="mt-content">
                                                <div class="mc-op"><?php echo e($result->tournament->getTranslatedAttribute('title')); ?></div>
                                                <h4><?php echo e($result->team_a_point); ?> : <?php echo e($result->getTranslatedAttribute('team_b_point')); ?></h4>
                                                <div class="mc-op"><?php echo e($result->tournament->date); ?></div>
                                            </td>
                                            <td class="right-team">
                                                <img src="<?php echo e(is_null($result->teamB->logo)?asset('frontend/assets/img/default.png'):Voyager::image($result->teamB->logo)); ?>" alt="team b">
                                                <h6><?php echo e($result->teamB->title); ?></h6>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
            <?php endif; ?>
            
        </div>
    </div>
</section>
<?php endif; ?><?php /**PATH C:\Users\ashah\Desktop\New folder (2)\tournament-management\resources\views/sections/matches.blade.php ENDPATH**/ ?>