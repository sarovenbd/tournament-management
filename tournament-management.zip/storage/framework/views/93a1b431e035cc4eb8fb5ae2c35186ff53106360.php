<?php if(count($streams)>0): ?>
    <section class="video-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="title">Live Streams</h3>
                    <hr class="line-info"> 
                </div>
            </div>
            <div class="row">
                <div class="video-slider owl-carousel">

                    <?php $__currentLoopData = $streams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stream): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3"> 
                            <div class="video-item set-bg" data-setbg="<?php echo e(is_null($stream->image)?asset('frontend/assets/img/default.png'):Voyager::image($stream->image)); ?>">
                                <a href="<?php echo e($stream->url); ?>" class="play-btn video-popup"><img src="<?php echo e(asset('frontend/assets/img/videos/play.png')); ?>" alt="video img"></a>
                                <div class="vi-time"><?php echo e($stream->status); ?></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </section> 
<?php endif; ?><?php /**PATH C:\Users\ashah\Desktop\New folder (2)\tournament-management\resources\views/sections/live-streams.blade.php ENDPATH**/ ?>