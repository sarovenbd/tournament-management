

<?php $__env->startSection('title','Tournaments'); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-header page-header-small">
    <div class="page-header-image" style="background-image: url('<?php echo e(asset('frontend/assets/img/header-bg.jpg')); ?>');">
    </div>
    <div class="content-center">
        <div class="row">
            <div class="col-md-6 ml-auto mr-auto text-center">
              <h1 class="title"><?php echo e(__('tournaments.page-title')); ?></h1>
            </div>
        </div>
    </div>
  </div>

  <div class="section">
    <div class="container table-responsive-md">
      <?php if(count($tournaments)>0): ?>
        <table class="table">
          <thead>
              <tr>
                  <th>Event</th>
                  <th>Venue</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th></th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <tr>
                <td><?php echo e($tournament->getTranslatedAttribute('title')); ?></td>
                <td><?php echo e($tournament->getTranslatedAttribute('venue')); ?></td>
                <td><?php echo e($tournament->date); ?></td>
                <td><?php echo e($tournament->status); ?></td>
                <td class="td-actions text-right">
                    <a href="/tournament/<?php echo e($tournament->slug); ?>" class="btn btn-info btn-sm">
                        View Details
                    </a>
                </td>
              </tr>
              
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

        <div class="row justify-content-center">
          <?php echo e($tournaments->links()); ?>

        </div>
      <?php endif; ?>
    </div>
  </div>
  
  <?php echo $__env->make('sections.matches', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('sections.live-streams', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ashah\Desktop\New folder (2)\tournament-management\resources\views/tournaments.blade.php ENDPATH**/ ?>