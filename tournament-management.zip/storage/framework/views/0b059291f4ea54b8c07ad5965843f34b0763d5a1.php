

<?php $__env->startSection('title', 'Teams'); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-header page-header-small">
      <div class="page-header-image" style="background-image: url('<?php echo e(asset('frontend/assets/img/header-bg.jpg')); ?>');">
      </div>
      <div class="content-center">
          <div class="row">
              <div class="col-md-6 ml-auto mr-auto text-center">
                  <h1 class="title"><?php echo e(__('teams.page-title')); ?></h1>
              </div>
          </div>
      </div>
  </div>

  <?php if(count($teams)>0): ?>

    <div class="section">
      <div class="container">
        <div class="row">
          <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mt-5">
              <div class="card">
                <div class="card-body">
                  <h2 class="title text-center"><?php echo e($team->getTranslatedAttribute('title')); ?></h2>
                  <div class="align-items-center d-flex justify-content-center mb-3">
                    <p class="text-muted">Founded <?php echo e(date('d F,Y', strtotime($team->founding_date))); ?></p>
                  </div>
                  
                  <div class="row d-flex justify-content-center">
                    <ul class="list-unstyled">
                      <li>
                        <?php $count = 0; ?>
                        <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($count == 4) break; ?>
                            <img class="teams-player-img img-fluid rounded-circle" src="<?php echo e(is_null($player->image)? asset('frontend/assets/img/default.png') :Voyager::image($player->image)); ?>">
                          <?php $count++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="card-footer">
                  <div class="align-items-center d-flex justify-content-center mb-2">
                    <a href="/team/<?php echo e($team->slug); ?>" class="btn btn-info">Team Page</a>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row justify-content-center mt-5">
          <?php echo e($teams->links()); ?>

        </div>

      </div>
    </div>  
  <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ashah\Desktop\New folder (2)\tournament-management\resources\views/teams.blade.php ENDPATH**/ ?>