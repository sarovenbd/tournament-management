<footer class="app-footer">
    <div class="site-footer-right">
        <?php if(rand(1,100) == 100): ?>
       
		© <?php echo e(date('Y')); ?> Copyright: <?php echo e(is_null(setting('site.title'))?'': setting('site.title')); ?>

		
		<?php else: ?>
			
		© <?php echo e(date('Y')); ?> Copyright: <?php echo e(is_null(setting('site.title'))?'': setting('site.title')); ?>

		
		<?php endif; ?>
			
    </div>
</footer>
<?php /**PATH C:\Users\ashah\Desktop\New folder (2)\tournament-management\resources\views/vendor/voyager/partials/app-footer.blade.php ENDPATH**/ ?>