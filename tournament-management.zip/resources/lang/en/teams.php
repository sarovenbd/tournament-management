<?php

return [
    'page-title'=> 'Teams',
];