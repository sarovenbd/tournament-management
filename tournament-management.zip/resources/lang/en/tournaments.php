<?php

return [
    'page-title'=> 'Tournaments',
];