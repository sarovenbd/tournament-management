<?php

return [
    'page-title'=> 'News',
];