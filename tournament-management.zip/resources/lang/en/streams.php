<?php

return [
    'page-title'=> 'Streams',
];